"""StudySpace · Field Notes Edition — accessible PDF reader and stationery workspace.

Run: python -m streamlit run app.py

The original Accessible PDF Reader comments are preserved in this file.
"""

import tempfile  # creates a temporary file
import os  # used to check if the temp file exists
import html  # prevents study notes from being interpreted as HTML
import json  # passes saved highlights and notes to the PDF exporter
import hashlib  # keeps each uploaded PDF's notes separate
from pathlib import Path  # finds the sample PDF and editor assets

import streamlit as st  # this creates the web app interface
import streamlit.components.v1 as components  # allows real drag-and-drop notes on PDFs
from pdf_tools import PALETTE, NOTE_COLORS, pdf_info, count_matches, annotated_pdf, render_page
from reader import page_visual_and_segments  # spoken-word positions on PDF pages

# pyttsx3 # text-to-speech conversion library
# The optional WAV downloader uses pyttsx3. For the live Read Aloud feature,
# we now use the browser so students can choose a voice and see spoken words.

# 1) add titles
st.set_page_config(
    # set up a title
    page_title="StudySpace | Your little reading nook",
    page_icon="📓",
    layout="wide",
    initial_sidebar_state="collapsed",
)

st.markdown("""
<style>
/* StudySpace · Field Notes Edition: calm granola palette with an editorial, paper-and-ink feel. */
@import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700;800&family=Fraunces:opsz,wght,SOFT,WONK@9..144,500,35,1;9..144,600,35,1;9..144,700,35,1&display=swap');
:root {--ink:#38382e;--muted:#746e61;--cream:#f6f2e9;--linen:#ede7da;--paper:#fffdf8;--line:#dcd4c3;--sage:#71836a;--dark-sage:#4e674f;--clay:#b8745c;--oat:#e5d4ae;--butter:#f2df9e;}
html,body,[data-testid="stApp"] {font-family:'DM Sans',Verdana,sans-serif;color:var(--ink);}
.stApp{background:#f5f0e6;background-image:radial-gradient(#ddd2c0 0.8px, transparent 0.8px);background-size:23px 23px;}
[data-testid="stHeader"]{background:transparent;height:2.5rem;}
.block-container{max-width:2200px;padding:.65rem 1.6rem 2.7rem;}
[data-testid="stSidebar"]{background:#ebe7dc;}
h1,h2,h3{font-family:'Fraunces',Georgia,serif;color:#3f463a;}
small,[data-testid="stCaptionContainer"]{color:#6b6b5f!important;}
[data-testid="stExpander"]{background:#fffcf5;border:1px solid #d9d0be;border-radius:15px;box-shadow:0 2px 0 #ddd3c2;}
[data-testid="stVerticalBlockBorderWrapper"] > div:has(> [data-testid="stVerticalBlock"]){border:1px solid #ded5c5!important;border-radius:15px!important;background:#fffdf8!important;}
[data-testid="stTabs"] [data-baseweb="tab-list"]{background:#ece7db;border-radius:12px;padding:4px;gap:4px;}
[data-testid="stTabs"] button[role="tab"]{font-size:.79rem;font-weight:800;border-radius:9px;padding:.47rem .65rem;color:#625c4e;}
[data-testid="stTabs"] button[role="tab"][aria-selected="true"]{background:#fdfbf5;color:#485c45;box-shadow:0 1px 5px #65594422;}
[data-testid="stTabs"] [data-baseweb="tab-highlight"],[data-testid="stTabs"] [data-baseweb="tab-border"]{display:none;}
[data-testid="stWidgetLabel"] p{font-size:.82rem;font-weight:700;color:#5f5d50;}
input,textarea{caret-color:#4f6d51;}
[data-baseweb="input"]>div,[data-baseweb="select"]>div,[data-baseweb="textarea"]>div{background:#fffefa!important;border-color:#dcd2bf!important;border-radius:10px!important;}
div.stButton > button,div.stDownloadButton > button,div.stFormSubmitButton > button{min-height:40px;border-radius:10px;border:1px solid #c9c5b3;background:#fffcf5;color:#485848;font-weight:800;box-shadow:0 2px 0 #e6dfd1;}
div.stButton > button:hover,div.stDownloadButton > button:hover,div.stFormSubmitButton > button:hover{border-color:#7e9277;background:#f0f5ec;color:#385a3d;}
div.stButton>button[kind="primary"],div.stDownloadButton>button[kind="primary"],div.stFormSubmitButton>button[kind="primary"]{background:#58735a;border-color:#58735a;color:#fffdf4;box-shadow:0 3px 0 #3e5743;}
div.stButton>button[kind="primary"]:hover,div.stDownloadButton>button[kind="primary"]:hover,div.stFormSubmitButton>button[kind="primary"]:hover{background:#47634c;color:white;}
:focus-visible {outline:3px solid #b77656!important;outline-offset:2px;}
/* Warm, illustrated masthead: not the default Streamlit dashboard look. */
.ss-header{position:relative;overflow:hidden;background:#fffaf0;border:1px solid #d5cbb8;border-radius:20px;margin:6px 0 13px;box-shadow:0 6px 0 #e5dccb,0 13px 25px #5c50391b;display:flex;gap:16px;justify-content:space-between;align-items:center;min-height:116px;padding:19px 29px;}
.ss-header:before{content:'';position:absolute;width:230px;height:220px;border-radius:50%;background:#e3eadb;right:13%;top:-171px;opacity:.65;}
.ss-header:after{content:'';position:absolute;width:145px;height:145px;border:1px solid #cfbaa2;border-radius:50%;right:-57px;bottom:-95px;opacity:.7;}
.ss-brand{display:flex;gap:18px;align-items:center;position:relative;z-index:1;}
.ss-icon{width:66px;height:67px;background:#e6dfc8;border:1px solid #cbbda3;border-radius:9px 16px 13px 7px;box-shadow:4px 5px 0 #bac8af,6px 8px 0 #e2d6c4;display:grid;place-items:center;font-size:34px;transform:rotate(-5deg);}
.ss-eyebrow{display:flex;align-items:center;gap:8px;color:#9b785f;text-transform:uppercase;letter-spacing:.21em;font-size:.61rem;font-weight:800;margin-bottom:6px;}
.ss-eyebrow::before{content:'';display:inline-block;width:21px;height:1px;background:#b9967a;}
.ss-name{font-family:'Fraunces',Georgia,serif;font-size:clamp(28px,3.2vw,43px);font-weight:700;color:#3f4c3c;letter-spacing:-.065em;line-height:1.02;}
.ss-name b{font-weight:700;color:#9b705a;}
.ss-sub{font-size:.8rem;color:#7a7567;font-weight:600;margin-top:7px;letter-spacing:.012em;}
.ss-right{display:flex;align-items:center;gap:9px;flex-wrap:wrap;z-index:1;}
.ss-tag{display:inline-flex;align-items:center;gap:7px;border:1px solid #d6d0bf;background:#f5f1e6;border-radius:99px;padding:8px 11px;color:#5d6b55;font-size:.72rem;font-weight:800;white-space:nowrap;}
.ss-tag.accent{background:#e8eee1;border-color:#ccd7c2;}
.ss-index{font-size:.66rem;font-weight:800;letter-spacing:.15em;color:#a4826a;margin-right:6px;text-transform:uppercase;}
.ss-file{background:#fffdf8;border:1px solid #d7cdbc;border-radius:16px;padding:11px 17px;display:flex;gap:15px;justify-content:space-between;align-items:center;flex-wrap:wrap;box-shadow:0 4px 0 #e9dfd1;margin:6px 0 13px;}
.ss-docname{font-size:.93rem;color:#44473c;font-weight:800;overflow-wrap:anywhere;}
.ss-detail{color:#847b6d;font-weight:600;font-size:.74rem;margin-top:4px;}
.ss-section{font-family:'Fraunces',Georgia,serif;font-size:1.18rem;font-weight:600;color:#454b3d;margin:12px 0 8px;}
.ss-muted{font-family:'DM Sans',Verdana,sans-serif;font-size:.73rem;color:#827b6d;font-weight:500;}
.ss-note{padding:12px;border:1px solid #cec2ab;border-radius:3px 13px 4px 3px;box-shadow:3px 4px 0 #d2c4ac;margin:11px 0;transform:rotate(-.7deg);color:#554838;}
.ss-note:nth-child(even){transform:rotate(.6deg);}
.ss-note-title{font-size:.81rem;font-weight:800;}.ss-note-body{font-size:.76rem;line-height:1.48;margin-top:6px;white-space:pre-wrap;overflow-wrap:anywhere;}
.ss-tip{background:#eef0e6;border:1px solid #d7decf;border-left:4px solid #819576;padding:12px 13px;border-radius:10px;font-size:.76rem;line-height:1.65;color:#555c4e;}
.ss-footnote{background:#eee8dc;border:1px dashed #cec5b4;border-radius:12px;padding:12px 15px;color:#67665a;font-size:.76rem;}
/* Custom Streamlit elements stay keyboard-friendly and high-contrast. */
@media(max-width:1100px){.ss-header{padding:14px 16px}.ss-right{display:none}.block-container{padding:.5rem .7rem 1.8rem}}
@media(max-width:640px){.ss-icon{width:50px;height:51px;font-size:28px}.ss-brand{gap:12px}.ss-header{min-height:94px}.ss-sub{font-size:.67rem}}
@media(prefers-reduced-motion:reduce){*,*:before,*:after{scroll-behavior:auto!important;transition:none!important}}
</style>
""", unsafe_allow_html=True)

BASE = Path(__file__).resolve().parent
SAMPLE_PDF = BASE / "sample_reading.pdf"
# This custom editor communicates note positions back to Python, unlike a static iframe.
pdf_editor = components.declare_component("studyspace_pdf_editor", path=str(BASE / "editor"))

for name, default in {"doc_hash": "", "page": 1, "notes": [], "highlights": [], "wav": None}.items():
    if name not in st.session_state:
        st.session_state[name] = default

@st.cache_data(show_spinner=False, max_entries=10)
def cached_info(data: bytes):
    return pdf_info(data)

@st.cache_data(show_spinner=False, max_entries=16)
def cached_page(data: bytes, index: int):
    return page_visual_and_segments(data, index)

@st.cache_data(show_spinner=False, max_entries=12)
def preview_pdf(data: bytes, highlights_json: str):
    # Sticky notes appear as draggable HTML over the PDF while editing,
    # so the preview only needs permanent highlights, not flattened notes.
    return annotated_pdf(data, json.loads(highlights_json), [])

@st.cache_data(show_spinner=False, max_entries=12)
def export_pdf(data: bytes, highlights_json: str, notes_json: str):
    return annotated_pdf(data, json.loads(highlights_json), json.loads(notes_json))

# 4a) edit after 1st draft
# add a button that checks whether the computer speech engine is working
# The live browser has a Try voice button and voice selection instead.
def generate_wav(text: str, speech_rate: int = 160, volume: float = 1.0):
    import pyttsx3  # text-to-speech conversion library
    # creates a temp file where the audio will be stored
    audio_file = tempfile.NamedTemporaryFile(delete=False, suffix=".wav")
    audio_path = audio_file.name  # saves the temporary file's path
    audio_file.close()  # closes the file before pyttsx3 writes to it
    try:
        engine = pyttsx3.init()  # starts the text-to-speech engine
        engine.setProperty("rate", speech_rate)  # applies the selected reading speed
        engine.setProperty("volume", volume)  # selected volume
        engine.save_to_file(text, audio_path)  # saves the typed text as audio
        engine.runAndWait()  # run speech engine
        engine.stop()  # stop the speech engine
        # checks whether the audio file was created successfully
        if os.path.exists(audio_path) and os.path.getsize(audio_path) > 44:
            with open(audio_path, "rb") as audio:  # opens the audio file
                return audio.read()  # reads the audio data
        raise RuntimeError("The audio file was not created.")
    finally:
        # deletes the temporary audio file
        if os.path.exists(audio_path):
            os.remove(audio_path)

# ------------ Branded reading desk ------------
st.markdown('''<div class="ss-header"><div class="ss-brand">
  <div class="ss-icon" aria-hidden="true">📓</div>
  <div><div class="ss-eyebrow">Your quiet study corner</div>
  <div class="ss-name">study<b>space.</b></div>
  <div class="ss-sub">Good books. Better focus. A little room to think.</div></div>
  </div><div class="ss-right"><span class="ss-index">FIELD NOTES / 01</span>
  <span class="ss-tag accent">✿ read + follow</span><span class="ss-tag">◫ movable notes</span>
  <span class="ss-tag">✎ gentle highlights</span></div></div>''', unsafe_allow_html=True)

with st.expander("📎  Your documents  ·  upload or switch a PDF", expanded=False):
    uploaded = st.file_uploader("Upload a PDF", type=["pdf"], help="Best for text-based PDFs. Scanned PDFs need OCR.")
    st.caption("You can practice using the sample PDF if you haven't uploaded one yet. Download your annotated PDF to keep notes permanently.")

pdf_bytes = uploaded.getvalue() if uploaded else SAMPLE_PDF.read_bytes()
filename = uploaded.name if uploaded else "Sample reading — the science of learning.pdf"
try:
    pages, page_texts = cached_info(pdf_bytes)
except Exception as error:
    st.error(f"Could not load this PDF: {error}")
    st.stop()

pdf_hash = hashlib.sha256(pdf_bytes).hexdigest()
if st.session_state.doc_hash != pdf_hash:
    st.session_state.doc_hash = pdf_hash
    st.session_state.page = 1
    st.session_state.notes = []
    st.session_state.highlights = []
    st.session_state.wav = None

page_no = min(pages, max(1, st.session_state.page))
page_index = page_no - 1
hjson = json.dumps(st.session_state.highlights, sort_keys=True)
preview_bytes = preview_pdf(pdf_bytes, hjson)

st.markdown(f'''<div class="ss-file"><div><div class="ss-docname">📄 &nbsp;{html.escape(filename)}</div>
<div class="ss-detail">{pages} pages · {sum(len(p.split()) for p in page_texts):,} words · {len(st.session_state.highlights)} highlights · {len(st.session_state.notes)} sticky notes</div></div>
<div class="ss-tag accent">● &nbsp;IN YOUR READING NOOK</div></div>''', unsafe_allow_html=True)

# ------------ Navigation and wide PDF ------------
prev, next_, choose, focus_col = st.columns([1.1, 1.1, 2.2, 1.6], vertical_alignment="bottom")
with prev:
    if st.button("← Previous", disabled=page_no <= 1, use_container_width=True):
        st.session_state.page = page_no - 1
        st.rerun()
with next_:
    if st.button("Next →", disabled=page_no >= pages, use_container_width=True):
        st.session_state.page = page_no + 1
        st.rerun()
with choose:
    choice = st.selectbox("PDF page", range(1, pages+1), index=page_index, format_func=lambda n:f"Page {n} of {pages}", label_visibility="collapsed")
    if choice != page_no:
        st.session_state.page = choice
        st.rerun()
with focus_col:
    focus = st.toggle("Full-width paper", value=False, help="Expand PDF editor and hide the study toolbox.")

if focus:
    workspace = st.container()
    inspector = None
else:
    workspace, inspector = st.columns([7.6, 2.4], gap="medium")

with workspace:
    st.markdown('<div class="ss-section">The reading desk <span class="ss-muted">· a page for everything on your mind</span></div>', unsafe_allow_html=True)
    page_data = cached_page(preview_bytes, page_index)
    notes_on_page = [n for n in st.session_state.notes if n.get('page') == page_index]
    result = pdf_editor(
        page_data=page_data,
        notes=notes_on_page,
        page=page_index,
        doc_hash=pdf_hash,
        key="studyspace_editor",
        default=None,
    )
    # The editor returns note positions on each completed drag or note edit.
    # Only accept updates for the currently open PDF and page.
    if isinstance(result, dict) and result.get('event') == 'notes' and result.get('doc_hash') == pdf_hash and result.get('page') == page_index:
        new_notes = []
        for note in (result.get('notes') or [])[:100]:
            if not isinstance(note, dict):
                continue
            try:
                x = min(76., max(0., float(note.get('x', 0))))
                y = min(90., max(0., float(note.get('y', 0))))
            except (ValueError, TypeError):
                continue
            new_notes.append({
                "id": str(note.get("id", ""))[:90], "page": page_index,
                "title": str(note.get("title", "Study note"))[:70],
                "body": str(note.get("body", ""))[:1000],
                "color": note.get("color") if note.get("color") in NOTE_COLORS else "Butter",
                "x": round(x, 2), "y": round(y, 2),
            })
        updated = [n for n in st.session_state.notes if n.get('page') != page_index] + new_notes
        if updated != st.session_state.notes:
            st.session_state.notes = updated
    with st.expander("♿ Accessible extracted text (select and copy)"):
        st.text_area("Text from this PDF page", page_texts[page_index], height=220, disabled=True)

if inspector is not None:
    with inspector:
        st.markdown('<div class="ss-section">Your desk drawer</div>', unsafe_allow_html=True)
        tab_notes, tab_mark, tab_audio = st.tabs(["Notes", "Highlight", "Audio"])
        with tab_notes:
            st.markdown('<div class="ss-tip">Choose <b>Place note</b> above the paper, click to stick it down, and type your thought. Drag the top edge to move it, or use × to remove it.</div>', unsafe_allow_html=True)
            notes_on_page = [n for n in st.session_state.notes if n.get('page') == page_index]
            st.caption(f"{len(notes_on_page)} notes on this page")
            for item in notes_on_page:
                fill = NOTE_COLORS.get(item['color'], NOTE_COLORS['Butter'])
                rgb = tuple(round(v*255) for v in fill)
                color = '#%02x%02x%02x' % rgb
                st.markdown(f'''<div class="ss-note" style="background:{color}"><div class="ss-note-title">{html.escape(item['title'])}</div>
                <div class="ss-note-body">{html.escape(item['body']) or '<em>Click the note on paper to type…</em>'}</div></div>''',unsafe_allow_html=True)
        with tab_mark:
            with st.form("highlight", clear_on_submit=True):
                phrase = st.text_input("Find phrase", placeholder="e.g. active recall")
                color = st.selectbox("Highlighter", list(PALETTE))
                all_pages = st.checkbox("Mark every page", value=False)
                go = st.form_submit_button("Add highlight", type="primary", use_container_width=True)
            if go:
                phrase = phrase.strip()
                matches = count_matches(pdf_bytes, phrase, list(range(pages)) if all_pages else [page_index]) if phrase else {}
                if sum(matches.values()) == 0:
                    st.warning("No matching text. Try a shorter phrase.")
                else:
                    for index, count in matches.items():
                        if count:
                            st.session_state.highlights.append({"page":index,"phrase":phrase,"color":color})
                    st.rerun()
            for index, h in enumerate(st.session_state.highlights):
                if h['page']==page_index:
                    st.caption(f"{h['color']} · {h['phrase']}")
                    if st.button("Remove", key=f"rmhi_{index}",use_container_width=True):
                        del st.session_state.highlights[index]
                        st.rerun()
        with tab_audio:
            st.markdown('<div class="ss-tip">Choose a voice in the bar <b>above the PDF</b>, click <b>Preview voice</b>, then <b>Read + follow</b>. More natural voices appear when available on your device.</div>', unsafe_allow_html=True)
            st.caption("Browser voices vary across Windows, Chrome and Edge. For better quality, try Microsoft natural voices if they appear in the voice menu.")
            with st.expander("Download page audio as WAV"):
                st.caption("This optional WAV uses your computer's pyttsx3 voice, not the browser voice selected above.")
                speed = st.slider("Reading Speed (words per minute):",100,300,160,10)
                volume = st.slider("Volume:",0.,1.,1.,.1)
                # 5) create a button that allows the user to start the reading
                if st.button("Generate WAV",use_container_width=True):
                    # checks if the text area is empty
                    if not page_texts[page_index].strip():
                        st.warning("Please upload a text-based PDF to read.")
                    else:
                        try:
                            st.session_state.wav = generate_wav(page_texts[page_index], speed, volume)
                        except Exception as error:
                            st.error(f"Speech generation failed: {error}")
                if st.session_state.wav:
                    # displays the audio player
                    st.audio(st.session_state.wav,format="audio/wav")
                    # creates a download button
                    st.download_button("Download Audio",st.session_state.wav,file_name="generated_speech.wav",mime="audio/wav")

# Save button appears AFTER processing editor notes, so newly placed/moved
# sticky notes are included in the PDF download without another click.
st.markdown('<div class="ss-section">Keep your field notes</div>',unsafe_allow_html=True)
saved = export_pdf(pdf_bytes,json.dumps(st.session_state.highlights,sort_keys=True),json.dumps(st.session_state.notes,sort_keys=True))
st.download_button("↓ Save annotated PDF",saved,file_name=f"{Path(filename).stem}_studyspace.pdf",mime="application/pdf",type="primary")
st.markdown('<div class="ss-footnote">☕ Your marks and sticky notes stay in this open session. Save an annotated copy before you close StudySpace. The notes will appear directly on your PDF.</div>', unsafe_allow_html=True)

# I created and launched a draft of the web app prototype.
# it accepts the text input from the user but it does
# not read the text aloud yet. I will work on that next.

# the second edit of the draft ended up with a text-to-speech engine that
# reads the text aloud. the next step is to fix the user design and
# make the web app more user-friendly. I will also add a feature that
# allows the user to download the audio file that is generated from the text.

# Original prototype comment wording retained for documentation:
# 2) create a large text area for user input
# label display
# height of the text area
# placeholder text
# 3) create a slider that allows the user to adjust the
# speed of the reading
# slowest reading speed
# fastest reading speed
# default reading speed
# values increment by 10
# 4) creates a slider that allows user to adjust the volume of the reading
# label display
# min volume
# max volume
# default volume
# determines how much the volume changes
# speaks sentence through the computer
# run speech engine
# stop the speech engine
# creates a temp file where the audio will be stored
# saves the temporary file's path.
# closes the file before pyttsx3 writes to it.
# sets the reading speed.
# sets the volume.
# saves the typed text as audio.
# completes the audio-generation process.
# checks whether the audio file was created successfully.
# displays a success message.
# opens the audio file.
# reads the audio data.
# ceates a download button.
# runs if the audio file was not created.
# deletes the temporary audio file.
