@echo off
cd /d "%~dp0"
echo Starting StudySpace - Field Notes Edition...
python -m streamlit run app.py
if errorlevel 1 (
  echo.
  echo If Streamlit is missing, first run: python -m pip install -r requirements.txt
  pause
)
